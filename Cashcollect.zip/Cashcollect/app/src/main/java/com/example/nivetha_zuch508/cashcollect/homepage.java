package com.example.nivetha_zuch508.cashcollect;

import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class homepage extends AppCompatActivity {

    EditText ed1,ed2,ed3,ed4,ed5;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        ed2 = (EditText) findViewById(R.id.editText2);
        ed3 = (EditText)findViewById(R.id.editText3);
        ed4 = (EditText) findViewById(R.id.editText4);
        ed5 = (EditText)findViewById(R.id.editText5);
        b1 = (Button) findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // Construct data
                    String apiKey = "apikey=" + "M75sYdRhU+o-veY4GL4RXoXTyrjyhwao6OQ6Ut6O26";
                    String message = "&message=" + ed3.getText().toString();
                    String sender = "&sender=" + "vicky";
                    String numbers = "&numbers=" + ed2.getText().toString();

                    // Send data
                    HttpURLConnection conn = (HttpURLConnection) new URL("https://api.txtlocal.com/send/?").openConnection();
                    String data = apiKey + numbers + message + sender;
                    conn.setDoOutput(true);
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
                    conn.getOutputStream().write(data.getBytes("UTF-8"));
                    final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    final StringBuffer stringBuffer = new StringBuffer();
                    String line;
                    while ((line = rd.readLine()) != null) {
                      //  stringBuffer.append(line);
                        Toast.makeText(getApplicationContext(),"message"+line,Toast.LENGTH_LONG).show();
                    }
                    rd.close();

                 //   return stringBuffer.toString();
                } catch (Exception e) {
                    System.out.println("Error SMS "+e);
                    Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_LONG).show();
                   // return "Error "+e;
                }
                try {
                    // Construct data
                    String apiKey = "apikey=" + "M75sYdRhU+o-veY4GL4RXoXTyrjyhwao6OQ6Ut6O26";
                    String message = "&message=" + ed5.getText().toString();
                    String sender = "&sender=" + "vicky";
                    String numbers = "&numbers=" + ed4.getText().toString();

                    // Send data
                    HttpURLConnection conn = (HttpURLConnection) new URL("https://api.txtlocal.com/send/?").openConnection();
                    String data = apiKey + numbers + message + sender;
                    conn.setDoOutput(true);
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
                    conn.getOutputStream().write(data.getBytes("UTF-8"));
                    final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    final StringBuffer stringBuffer = new StringBuffer();
                    String line;
                    while ((line = rd.readLine()) != null) {
                        //  stringBuffer.append(line);
                        Toast.makeText(getApplicationContext(),"message"+line,Toast.LENGTH_LONG).show();
                    }
                    rd.close();

                    //   return stringBuffer.toString();
                } catch (Exception e) {
                    System.out.println("Error SMS "+e);
                    Toast.makeText(getApplicationContext(),"error"+e,Toast.LENGTH_LONG).show();
                    // return "Error "+e;
                }
            }
        });
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }
}
